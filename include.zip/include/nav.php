<ul>
	<li><a href="index.php">HOME</a></li>
	<li><a href="all_product.php">ALL PRODUCTS</a></li>
	<li><a href="1.myaccount.php">MY ACCOUNT</a></li>
	<li><a href="#">SHORTCODES</a></li>
	<li><a href="cart.php">CART</a></li>
	<li><a href="#">CONTACT</a></li>
	<li><abbr title="Notification Bell"><i class="far fa-bell"></i></abbr></li>
</ul>