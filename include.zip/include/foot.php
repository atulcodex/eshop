
<table width="30%" id="on">
	<tr>
		<th align="center"><img src="img/logo.png" width="320"><br></th>
	</tr>
	<tr align="center">
		<td>
			Took a gallery of type and scrambled it to make a type specimen book. it has survived not only five centuries, but also the leap into electronictook a gallery of type and scrambled it to make.
		</td>
	</tr>

	<tr>
		<td>
			<!--keep this blank for space-->
		</td>
	</tr>

	<tr align="center">
		<td>
			<h2> FOLLOW US ON </h2>
		</td>
	</tr>

	<tr align="center">
		<td id="fafa"><h1>
			<a href=""><i class="fa fa-facebook-official" aria-hidden="true"></i></a>
			<a href=""><i class="fa fa-twitter" aria-hidden="true"></i></a>
			<a href=""><i class="fa fa-google-plus" aria-hidden="true"></i></a>
			<a href=""><i class="fa fa-instagram" aria-hidden="true"></i></a>
			<a href=""><i class="fa fa-youtube" aria-hidden="true"></i></a>
		</h1></td>
	</tr>
</table>

<table id="own">
	<tr align="left">
		<th>INFORMATION</th>
		<th>POLICIES</th>
		<th>GET IN TOUCH</th>
	</tr>

	<tr align="left">
		<td><a href="#"> > Store Locator</a></td>
		<td><a href="#"> > Online Shopping</a></td>
		<td> <i class="fa fa-map-marker" aria-hidden="true"></i>60 29th Street San Francisco,
</td>
	</tr>

	<tr align="left">
		<td><a href="#"> > Shipping Details</a></td>
		<td><a href="#"> > Orders and Returns</a></td>
		<td> CA 94110 United States of America</td>
	</tr>

	<tr align="left">
		<td><a href="#"> > Track an Order</a></td>
		<td><a href="#"> > Discount offers</a></td>
		<td> <i class="fa fa-phone" aria-hidden="true"></i> +91 7303 033651</td>
	</tr>

	<tr align="left">
		<td><a href="#"> > Affiliate</a></td>
		<td><a href="#"> > Investor Relationship</a></td>
		<td> <i class="fa fa-envelope-o" aria-hidden="true"></i> atul@justano.com</td>
	</tr>

	<tr align="left">
		<td><a href="#"> > Discount on products</a></td>
		<td><a href="#"> > Corporate Responsibility</a></td>
	</tr>

	<tr align="left">
		<td colspan="3">all rights reserved &copy;2018 by justano.com | Designed By Atul.</td>
	</tr>
</table>